fun main() {
    println("Happy Birthday!")
    println("Jhansi")
    println("You are 25!")
}